package com.invoicepro.app.data.local.dao

import androidx.room.*
import com.invoicepro.app.data.local.entities.InvoiceEntity
import com.invoicepro.app.data.local.entities.PaymentStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface InvoiceDao {
    @Query("SELECT * FROM invoices ORDER BY issueDate DESC, createdAt DESC")
    fun getAllInvoices(): Flow<List<InvoiceEntity>>

    @Query("SELECT * FROM invoices WHERE id = :id LIMIT 1")
    suspend fun getInvoiceById(id: String): InvoiceEntity?

    @Query("SELECT * FROM invoices WHERE status = :status ORDER BY issueDate DESC")
    fun getInvoicesByStatus(status: PaymentStatus): Flow<List<InvoiceEntity>>

    @Query("""
        SELECT * FROM invoices 
        WHERE invoiceNumber LIKE '%' || :query || '%' 
           OR customerName LIKE '%' || :query || '%'
           OR customerCompany LIKE '%' || :query || '%'
        ORDER BY issueDate DESC
    """)
    fun searchInvoices(query: String): Flow<List<InvoiceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoice(invoice: InvoiceEntity)

    @Update
    suspend fun updateInvoice(invoice: InvoiceEntity)

    @Query("DELETE FROM invoices WHERE id = :id")
    suspend fun deleteInvoiceById(id: String)

    @Query("SELECT COUNT(*) FROM invoices")
    fun getInvoiceCount(): Flow<Int>

    @Query("SELECT SUM(grandTotal) FROM invoices")
    fun getTotalRevenue(): Flow<Double?>

    @Query("SELECT SUM(paidAmount) FROM invoices")
    fun getTotalCollected(): Flow<Double?>

    @Query("SELECT SUM(balanceDue) FROM invoices WHERE status != 'PAID'")
    fun getTotalOutstanding(): Flow<Double?>
}
