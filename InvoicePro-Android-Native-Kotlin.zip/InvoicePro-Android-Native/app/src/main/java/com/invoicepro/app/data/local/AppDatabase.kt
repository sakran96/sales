package com.invoicepro.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.invoicepro.app.data.local.converters.InvoiceTypeConverters
import com.invoicepro.app.data.local.dao.CustomerDao
import com.invoicepro.app.data.local.dao.InvoiceDao
import com.invoicepro.app.data.local.dao.PaymentDao
import com.invoicepro.app.data.local.dao.ProductDao
import com.invoicepro.app.data.local.entities.*

@Database(
    entities = [
        InvoiceEntity::class,
        CustomerEntity::class,
        ProductEntity::class,
        PaymentEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(InvoiceTypeConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun invoiceDao(): InvoiceDao
    abstract fun customerDao(): CustomerDao
    abstract fun productDao(): ProductDao
    abstract fun paymentDao(): PaymentDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "invoice_pro.db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
