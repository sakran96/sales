package com.invoicepro.app.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.print.PrintAttributes
import android.print.PrintManager
import com.invoicepro.app.data.local.entities.InvoiceEntity
import java.io.File
import java.io.FileOutputStream

object PdfInvoiceGenerator {

    /**
     * Generates a multi-page A4 PDF file using native Android PdfDocument
     */
    fun generateInvoicePdf(context: Context, invoice: InvoiceEntity): File {
        // A4 page dimensions at 72 DPI: 595 x 842 points
        val pageWidth = 595
        val pageHeight = 842
        val document = PdfDocument()

        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val paint = Paint().apply {
            isAntiAlias = true
            color = Color.BLACK
        }

        // Header Banner
        paint.color = Color.parseColor(invoice.primaryColor)
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 90f, paint)

        // Title
        paint.color = Color.WHITE
        paint.textSize = 24f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("INVOICE PRO", 40f, 55f, paint)

        // Invoice Number
        paint.textSize = 14f
        canvas.drawText(invoice.invoiceNumber, (pageWidth - 180).toFloat(), 55f, paint)

        // Client Info
        paint.color = Color.DKGRAY
        paint.textSize = 12f
        paint.typeface = Typeface.DEFAULT
        canvas.drawText("Billed To:", 40f, 130f, paint)
        paint.color = Color.BLACK
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(invoice.customerName, 40f, 150f, paint)
        paint.typeface = Typeface.DEFAULT
        canvas.drawText(invoice.customerAddress, 40f, 170f, paint)

        // Table Header
        paint.color = Color.LTGRAY
        canvas.drawRect(40f, 210f, (pageWidth - 40).toFloat(), 235f, paint)
        paint.color = Color.BLACK
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Item / Description", 50f, 228f, paint)
        canvas.drawText("Qty", 320f, 228f, paint)
        canvas.drawText("Price", 390f, 228f, paint)
        canvas.drawText("Total", 480f, 228f, paint)

        // Line Items
        var yPos = 260f
        paint.typeface = Typeface.DEFAULT
        for (item in invoice.items) {
            canvas.drawText(item.description, 50f, yPos, paint)
            canvas.drawText(item.quantity.toString(), 320f, yPos, paint)
            canvas.drawText(String.format("%.2f", item.unitPrice), 390f, yPos, paint)
            canvas.drawText(String.format("%.2f", item.total), 480f, yPos, paint)
            yPos += 25f
        }

        // Totals Box
        yPos += 20f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Grand Total: ${invoice.currency} ${String.format("%.2f", invoice.grandTotal)}", 350f, yPos, paint)
        yPos += 20f
        canvas.drawText("Paid: ${invoice.currency} ${String.format("%.2f", invoice.paidAmount)}", 350f, yPos, paint)
        yPos += 20f
        paint.color = Color.RED
        canvas.drawText("Balance Due: ${invoice.currency} ${String.format("%.2f", invoice.balanceDue)}", 350f, yPos, paint)

        document.finishPage(page)

        // Save PDF to cache or external storage
        val outputFile = File(context.cacheDir, "${invoice.invoiceNumber}.pdf")
        FileOutputStream(outputFile).use { out ->
            document.writeTo(out)
        }
        document.close()
        return outputFile
    }

    /**
     * Sends the PDF to the Android Print Framework
     */
    fun printInvoice(context: Context, invoice: InvoiceEntity) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val jobName = "InvoicePro_${invoice.invoiceNumber}"
        val printAdapter = InvoicePrintDocumentAdapter(context, invoice)
        printManager.print(jobName, printAdapter, PrintAttributes.Builder().build())
    }
}
