package com.invoicepro.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.invoicepro.app.data.local.dao.CustomerDao
import com.invoicepro.app.data.local.dao.InvoiceDao
import com.invoicepro.app.data.local.dao.ProductDao
import com.invoicepro.app.data.local.entities.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode

data class DashboardMetrics(
    val totalInvoices: Int = 0,
    val totalRevenue: Double = 0.0,
    val totalCollected: Double = 0.0,
    val totalOutstanding: Double = 0.0,
    val overdueCount: Int = 0
)

class InvoiceViewModel(
    private val invoiceDao: InvoiceDao,
    private val customerDao: CustomerDao,
    private val productDao: ProductDao
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _statusFilter = MutableStateFlow<PaymentStatus?>(null)
    val statusFilter: StateFlow<PaymentStatus?> = _statusFilter.asStateFlow()

    val allInvoices: StateFlow<List<InvoiceEntity>> = combine(
        invoiceDao.getAllInvoices(),
        _searchQuery,
        _statusFilter
    ) { invoices, query, status ->
        invoices.filter { inv ->
            val matchesQuery = query.isBlank() ||
                inv.invoiceNumber.contains(query, ignoreCase = true) ||
                inv.customerName.contains(query, ignoreCase = true)
            val matchesStatus = status == null || inv.status == status
            matchesQuery && matchesStatus
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customers: StateFlow<List<CustomerEntity>> = customerDao.getAllCustomers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val products: StateFlow<List<ProductEntity>> = productDao.getAllProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val metrics: StateFlow<DashboardMetrics> = invoiceDao.getAllInvoices()
        .map { list ->
            DashboardMetrics(
                totalInvoices = list.size,
                totalRevenue = list.sumOf { it.grandTotal },
                totalCollected = list.sumOf { it.paidAmount },
                totalOutstanding = list.sumOf { it.balanceDue },
                overdueCount = list.count { it.status == PaymentStatus.OVERDUE }
            )
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardMetrics())

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setStatusFilter(status: PaymentStatus?) {
        _statusFilter.value = status
    }

    fun saveInvoice(invoice: InvoiceEntity) {
        viewModelScope.launch {
            invoiceDao.insertInvoice(invoice)
        }
    }

    fun deleteInvoice(id: String) {
        viewModelScope.launch {
            invoiceDao.deleteInvoiceById(id)
        }
    }

    fun recordPayment(invoiceId: String, amount: Double) {
        viewModelScope.launch {
            val invoice = invoiceDao.getInvoiceById(invoiceId) ?: return@launch
            val newPaid = BigDecimal(invoice.paidAmount).add(BigDecimal(amount)).setScale(2, RoundingMode.HALF_UP).toDouble()
            val newBalance = BigDecimal(invoice.grandTotal).subtract(BigDecimal(newPaid)).coerceAtLeast(BigDecimal.ZERO).setScale(2, RoundingMode.HALF_UP).toDouble()
            val newStatus = if (newBalance <= 0.0) PaymentStatus.PAID else PaymentStatus.PARTIALLY_PAID
            
            val updated = invoice.copy(
                paidAmount = newPaid,
                balanceDue = newBalance,
                status = newStatus,
                updatedAt = System.currentTimeMillis()
            )
            invoiceDao.updateInvoice(updated)
        }
    }
}
