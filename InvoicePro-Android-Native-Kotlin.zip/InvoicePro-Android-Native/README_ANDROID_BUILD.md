# INVOICE PRO — Android Native Build & Signing Guide

### System Prerequisites
- **Java Development Kit (JDK)**: Version 17 or higher (`openjdk-17-jdk`)
- **Android Studio**: Ladybug (2024.2+) or Hedgehog+
- **Android SDK**: API 35 (Android 15) with platform-tools and build-tools 35.0.0
- **Gradle**: 8.7+ (Wrapper included: `./gradlew`)

---

### Step 1: Open Project in Android Studio
1. Clone or extract the project files into a folder (e.g. `InvoiceProAndroid/`).
2. Launch **Android Studio**.
3. Select **Open** and choose the root directory of the project.
4. Allow Gradle sync to complete and download Room KSP and Compose dependencies.

---

### Step 2: Build Debug APK via Command Line
Run the following in your terminal inside the project root:
```bash
# Grant execution permissions to Gradle wrapper
chmod +x gradlew

# Build debug APK
./gradlew assembleDebug
```
The generated debug APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`

To install directly to a connected Android phone or emulator:
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

---

### Step 3: Generate a Production Keystore
Generate a cryptographically secure RSA keystore for release signing:
```bash
keytool -genkey -v -keystore invoicepro-release.keystore \
  -alias invoicepro_key \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass YourSecurePassword123 \
  -keypass YourSecurePassword123 \
  -dname "CN=Invoice Pro, OU=Engineering, O=InvoicePro, L=Riyadh, C=SA"
```

---

### Step 4: Configure Release Signing in `app/build.gradle.kts`
Add your signing credentials:
```kotlin
signingConfigs {
    create("release") {
        storeFile = file("../invoicepro-release.keystore")
        storePassword = "YourSecurePassword123"
        keyAlias = "invoicepro_key"
        keyPassword = "YourSecurePassword123"
    }
}

buildTypes {
    release {
        isMinifyEnabled = true
        isShrinkResources = true
        signingConfig = signingConfigs.getByName("release")
        proguardFiles(
            getDefaultProguardFile("proguard-android-optimize.txt"),
            "proguard-rules.pro"
        )
    }
}
```

---

### Step 5: Build and Sign Production Release APK / AAB
```bash
# Build signed production APK:
./gradlew assembleRelease

# Or build Google Play App Bundle (.aab):
./gradlew bundleRelease
```

Verify signature with `apksigner`:
```bash
$ANDROID_HOME/build-tools/35.0.0/apksigner verify --verbose app/build/outputs/apk/release/app-release.apk
```

---

### Step 6: Architecture Verification
- **Offline First**: All invoices, customers, products and payment histories are persisted locally in SQLite via Room.
- **Bilingual RTL/LTR**: Auto-adapts layout direction to Arabic (`ar`) and English (`en`).
- **A4 PDF Export**: Uses Android `PdfDocument` with clean margins and vector text.
- **Android Print**: Native `PrintDocumentAdapter` sends invoices to thermal Bluetooth printers or network printers.
- **Google Drive Cloud Sync**: Seamless cross-device Room SQLite database backup and restoration via Google Drive REST v3 API.
