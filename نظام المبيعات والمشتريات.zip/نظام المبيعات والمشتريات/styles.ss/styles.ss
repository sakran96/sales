body {
  font-family: sans-serif;
  direction: rtl;
  padding: 20px;
  background: #f0f2f5;
}

h1 {
  text-align: center;
  color: #333;
}

.dashboard {
  display: flex;
  justify-content: space-around;
  margin-bottom: 30px;
}

.card {
  background: #4caf50;
  color: white;
  padding: 30px;
  border-radius: 10px;
  width: 30%;
  text-align: center;
  font-size: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.card:hover {
  background: #388e3c;
}

.section {
  background: #fff;
  padding: 15px;
  margin-bottom: 30px;
  border-radius: 8px;
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

input, select, button {
  margin: 5px;
  padding: 6px;
  font-size: 14px;
}

ul {
  list-style: none;
  padding: 0;
}

li {
  background: #fafafa;
  margin: 5px 0;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 5px;
}