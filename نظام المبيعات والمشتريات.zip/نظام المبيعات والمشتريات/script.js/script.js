let products = JSON.parse(localStorage.getItem('products')) || [];
let sales = JSON.parse(localStorage.getItem('sales')) || [];

function saveToStorage() {
  localStorage.setItem('products', JSON.stringify(products));
}

function addProduct() {
  const name = document.getElementById('productName').value.trim();
  const qtyInput = document.getElementById('productQty').value;
  const isUnlimited = document.getElementById('unlimitedQty').checked;
  const unit = document.getElementById('unit').value.trim() || 'وحدة';
  const purchasePrice = parseFloat(document.getElementById('purchasePrice').value);
  const salePrice = parseFloat(document.getElementById('salePrice').value);

  if (!name || (!isUnlimited && (!qtyInput || qtyInput < 0))) {
    alert('يرجى إدخال اسم وكميات صحيحة');
    return;
  }

  const qty = isUnlimited ? 'unlimited' : parseInt(qtyInput);
  products.push({ name, qty, unit, purchasePrice, salePrice });
  saveToStorage();
  updateProductList();
  updateSaleProductOptions();
}

function updateProductList() {
  const list = document.getElementById('productList');
  list.innerHTML = '';
  const keyword = document.getElementById('searchInput').value.toLowerCase();
  const unitFilter = document.getElementById('unitFilter').value.toLowerCase();
  const priceFilter = parseFloat(document.getElementById('priceFilter').value) || 0;

  products.filter(p =>
    p.name.toLowerCase().includes(keyword) &&
    p.unit.toLowerCase().includes(unitFilter) &&
    p.salePrice >= priceFilter
  ).forEach(p => {
    const qtyText = p.qty === 'unlimited' ? 'غير محدودة' : `${p.qty} ${p.unit}`;
    const li = document.createElement('li');
    li.textContent = `${p.name} - ${qtyText} | شراء: ${p.purchasePrice} | بيع: ${p.salePrice}`;
    list.appendChild(li);
  });
}

function updateSaleProductOptions() {
  const select = document.getElementById('saleProduct');
  select.innerHTML = '';
  products.forEach(p => {
    const option = document.createElement('option');
    option.value = p.name;
    option.textContent = p.name;
    select.appendChild(option);
  });
}

function showAvailableQty() {
  const name = document.getElementById('saleProduct').value;
  const product = products.find(p => p.name === name);
  if (!product) return;
  const qty = product.qty === 'unlimited' ? 'غير محدودة' : `${product.qty} ${product.unit}`;
  document.getElementById('availableQty').textContent = `الكمية المتاحة: ${qty}`;
}

async function addSale() {
  const name = document.getElementById('saleProduct').value.trim();
  const qty = parseInt(document.getElementById('saleQty').value);
  const product = products.find(p => p.name === name);

  if (!product) return alert('المنتج غير موجود');
  if (product.qty !== 'unlimited' && product.qty === 0) return alert('الكمية غير متوفرة');
  if (qty <= 0 || isNaN(qty)) return alert('أدخل كمية صحيحة');
  if (product.qty !== 'unlimited' && product.qty < qty) return alert('الكمية غير كافية');

  if (product.qty !== 'unlimited') product.qty -= qty;
  const profit = product.salePrice * qty - product.purchasePrice * qty;

  sales.push({ name, qty, date: new Date().toISOString(), profit });
  localStorage.setItem('sales', JSON.stringify(sales));

  alert('تم تسجيل البيع');
  saveToStorage();
  updateProductList();
  await generateInvoice(name, qty);
  showAvailableQty();
}

function filterSales() {
  const date = document.getElementById('salesDate').value;
  const report = document.getElementById('salesReport');
  report.innerHTML = '';

  const filtered = sales.filter(s => s.date.startsWith(date));
  filtered.forEach(s => {
    const li = document.createElement('li');
    li.textContent = `${s.name} - ${s.qty} وحدة - ربح: ${s.profit} - ${new Date(s.date).toLocaleString('ar-EG')}`;
    report.appendChild(li);
  });
}

async function generateInvoice(name, qty) {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const product = products.find(p => p.name === name);
  const date = new Date().toLocaleString('ar-EG');
  const unit = product.unit;
  const totalSale = product.salePrice * qty;
  const totalBuy = product.purchasePrice * qty;
  const profit = totalSale - totalBuy;

  doc.setFont("courier", "normal");
  doc.setFontSize(14);
  doc.text("فاتورة بيع", 105, 20, null, null, 'center');
  doc.text(`التاريخ: ${date}`, 20, 40);
  doc.text(`المنتج: ${name}`, 20, 50);
  doc.text(`الكمية: ${qty} ${unit}`, 20, 60);
  doc.text(`سعر البيع: ${product.salePrice}`, 20, 70);
  doc.text(`الإجمالي: ${totalSale} جنيه`, 20, 80);
  doc.text(`الربح: ${profit} جنيه`, 20, 90);
  doc.text("شكراً لتعاملكم معنا!", 20, 110);

  doc.save(`فاتورة-${name}-${Date.now()}.pdf`);
}

function scrollToSection(id) {
  document.getElementById(id).scrollIntoView({ behavior: 'smooth' });
}

// التهيئة
updateProductList();
updateSaleProductOptions();